***********Instructions for full application**********

///The mobile apk will be available in the below mentioned drive folder. Path: UP176_TECHNES > applications


///Sign up is compulsary before accessing the application. Don't be afraid of data stealing. The user sign in data will be stored locally where the password will be encrypted.


///Use the image target.jpeg provided to scan and run the application. For better user experience take print of the image target and then use it with the application.


///Our complete project will be available on google drive in the following link: "https://drive.google.com/file/d/1KjJSYwKw5sN02xPrurbbbVKkcGakPzjn/view?usp=sharing"


///Download the zip file from google drive and unzip the files for using it.


///Our project is built is using unity 2018.4.14f1. Pls use the same version to view our project without any problems.


///use visual studio 2017 to view our C# scripts.



